# PathSnap inference bundle v0.1.3

Exported and verified with Python 3.14.4 on Linux.
Use Python 3.14 and install the pinned runtime requirements.
The loader rejects different Python minor versions or package versions before loading weights.

From this extracted directory, create/activate a virtual environment, then:

```bash
python -m pip install -r requirements.txt
python run_inference.py --bundle . --trip-dir /path/to/00000007 --output prediction.json
```

Input folder requires only 00000007.track, 00000007.nodes and 00000007.arcs.
File columns are longitude/latitude/timestamp, longitude/latitude, and integer from/to node IDs.
No .route file is opened. No dataset, reference labels, evaluation reports or trip registry is included.
The original PathSnap repository is not needed to run this bundle.

The output has one entry per original GPS row, selected road IDs, explicit resets and separate
route parts with GeoJSON MultiLineString geometry. No accuracy or reference labels are returned.
Invalid GPS rows are retained as null predictions; invalid road geometry is rejected.

Model: selected tuned Random Forest. Features are unscaled; there is no learned scaler to export.
Preprocessing and HMM settings are frozen. No optimisation or model training runs during inference.
Road networks are supplied per trip and are not globally baked into the model.

Only load trusted bundles: joblib/pickle can execute code. File checksums detect corruption,
not the authenticity of a modified manifest. Manifest code/config hashes bind this exact snapshot;
base_git_revision records its parent source revision, not a claim that pending export code was
already committed there. Compatible wheels must be available for the target OS/environment.
